package com.integration.mediation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediationApplicationTests {

	@Test
	void contextLoads() {
	}

}
